
var JavascriptTask = function(){};
JavascriptTask.prototype = {
	initialize : function() {
	}
	,
	destory : function() {
	}
};